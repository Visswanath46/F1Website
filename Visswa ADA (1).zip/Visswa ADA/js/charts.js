// Top Speed by Team (Bar Chart)
const ctx1 = document.getElementById('topSpeedChart').getContext('2d');
new Chart(ctx1, {
  type: 'bar',
  data: {
    labels: ['Red Bull', 'Mercedes', 'Ferrari', 'McLaren', 'Aston Martin'],
    datasets: [{
      label: 'Top Speed (km/h)',
      data: [342, 336, 334, 330, 328],
      backgroundColor: '#e10600'
    }]
  },
  options: {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'Top Speed by F1 Team'
      }
    }
  }
});

// Win Share (Doughnut Chart)
const ctx2 = document.getElementById('winShareChart').getContext('2d');
new Chart(ctx2, {
  type: 'doughnut',
  data: {
    labels: ['Red Bull', 'Mercedes', 'Ferrari', 'McLaren'],
    datasets: [{
      label: 'Wins',
      data: [18, 9, 4, 2],
      backgroundColor: ['#e10600', '#00d2be', '#dc0000', '#ff8700']
    }]
  },
  options: {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'Team Win Share (Season)'
      }
    }
  }
});

// Lap Time Progression (Line Chart)
const ctx3 = document.getElementById('lapTimeChart').getContext('2d');
new Chart(ctx3, {
  type: 'line',
  data: {
    labels: ['Race 1', 'Race 2', 'Race 3', 'Race 4', 'Race 5'],
    datasets: [{
      label: 'Average Lap Time (sec)',
      data: [82.5, 81.2, 80.8, 80.4, 80.1],
      borderColor: '#e10600',
      fill: false,
      tension: 0.3
    }]
  },
  options: {
    responsive: true,
    plugins: {
      title: {
        display: true,
        text: 'Average Lap Time Over Races'
      }
    }
  }
});
