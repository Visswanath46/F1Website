// 1. Change nav on scroll
const nav        = document.getElementById('mainNav');
const hero       = document.querySelector('.hero') || document.querySelector('.sub-hero');
const navTrigger = hero ? hero.offsetHeight - 80 : 80;

window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > navTrigger);
});

// 2. Intersection Observer for fade-ins
const cards = document.querySelectorAll('.fade-in');
const io    = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting){ e.target.classList.add('in-view'); }});
},{threshold:.15});
cards.forEach(card => io.observe(card));
