const ctx   = document.getElementById('projectChart');
const months= ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const builds= [4,5,6,4,7,8,9,7,6,5,4,7];          // completed projects
const revenue=[.6,.9,1.1,.8,1.4,1.7,1.9,1.5,1.3,1.2,0.9,1.5]; // $M

new Chart(ctx,{
  type:'bar',
  data:{
    labels:months,
    datasets:[
      {label:'Projects Completed', data:builds, yAxisID:'y', borderWidth:1},
      {label:'Revenue (M$)', data:revenue, yAxisID:'y1', type:'line', tension:.3, pointRadius:4}
    ]
  },
  options:{
    responsive:true,
    interaction:{mode:'index',intersect:false},
    scales:{
      y :{beginAtZero:true,title:{text:'Projects',display:true}},
      y1:{beginAtZero:true,title:{text:'Revenue (Million $)',display:true},position:'right',grid:{drawOnChartArea:false}}
    }
  }
});
