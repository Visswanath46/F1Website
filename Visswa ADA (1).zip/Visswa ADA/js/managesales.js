const form   = document.getElementById('projectForm');
const table  = document.getElementById('projectTable').querySelector('tbody');
let   data   = JSON.parse(localStorage.getItem('projects') || '[]');

renderTable();

form.addEventListener('submit', e => {
  e.preventDefault();
  const idx     = document.getElementById('rowIndex').value;
  const project = {
    name:   document.getElementById('projectName').value,
    client: document.getElementById('client').value,
    budget: Number(document.getElementById('budget').value),
  };
  if (idx === '') { data.push(project); }         // CREATE
  else            { data[idx] = project; }        // UPDATE
  form.reset(); document.getElementById('rowIndex').value='';
  persist(); renderTable();
});

function renderTable(){
  table.innerHTML = '';
  data.forEach((p,i)=>{
    const tr = table.insertRow();
    tr.innerHTML = `<td>${p.name}</td><td>${p.client}</td><td>$${p.budget.toLocaleString()}</td>
    <td>
      <button onclick="editRow(${i})">Edit</button>
      <button onclick="deleteRow(${i})">Delete</button>
    </td>`;
  });
}
window.editRow = i => {
  const p = data[i];
  document.getElementById('projectName').value = p.name;
  document.getElementById('client').value      = p.client;
  document.getElementById('budget').value      = p.budget;
  document.getElementById('rowIndex').value    = i;
}
window.deleteRow = i => { data.splice(i,1); persist(); renderTable(); };

function persist(){ localStorage.setItem('projects', JSON.stringify(data)); }
