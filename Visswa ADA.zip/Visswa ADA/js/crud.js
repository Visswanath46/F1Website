const carForm = document.getElementById('carForm');
const carList = document.getElementById('carList');

// Static image for all cards
const carImage = 'img/car.png';


carForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById('carName').value.trim();
  const carClass = document.getElementById('carClass').value.trim();
  const team = document.getElementById('carTeam').value.trim();

  if (!name || !carClass || !team) return;

  const card = document.createElement('div');
  card.classList.add('car-card');

  card.innerHTML = `
    <img src="${carImage}" alt="F1 Car" />
    <div class="car-info">
      <h2>${name}</h2>
      <p><strong>Class:</strong> ${carClass}</p>
      <p><strong>Team:</strong> ${team}</p>
      <button class="delete-btn">Delete</button>
    </div>
  `;

  card.querySelector('.delete-btn').addEventListener('click', () => {
    card.remove();
  });

  carList.appendChild(card);

  carForm.reset();
});
